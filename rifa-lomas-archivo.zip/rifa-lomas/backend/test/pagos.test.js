import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import {
  cancelarCompra, conciliacion, crearOrden, eliminarCompra, estadoOrden, liberarVencidas, marcarAvisado,
  marcarWspTocado, panel, procesarPago, sortearExtra,
} from '../src/orders.js';
import { aplicarEsquema } from '../src/db.js';
import { SORTEO_CADA, chancesDe, leerPremios } from '../src/sorteo.js';
import { comprador, contar, nuevoEntorno } from './helpers.js';

let pool, mp;
before(async () => { ({ pool, mp } = await nuevoEntorno()); });
after(() => pool.end());

const pagar = (orden, extra = {}) =>
  mp.simularPago({ ref: orden.ref, amount: orden.monto, ...extra });

describe('asociación pago ↔ orden', () => {
  it('Pepito Gamer paga y Pepito Mamó no: solo la orden de Gamer se habilita', async () => {
    const gamer = await crearOrden(pool, comprador({ nombre: 'Pepito Gamer', cantidad: 2 }));
    const mamo = await crearOrden(pool, comprador({ nombre: 'Pepito Mamó', cantidad: 2 }));

    const r = await procesarPago(pool, mp, pagar(gamer));
    assert.equal(r.resultado, 'asignado');

    const g = await estadoOrden(pool, gamer.ref);
    const m = await estadoOrden(pool, mamo.ref);
    assert.equal(g.estado, 'pagada');
    assert.equal(g.numeros.length, 2);
    assert.equal(m.estado, 'pendiente');
    assert.equal(m.numeros, undefined);
    const vendidosMamo = await pool.query(
      `select count(*)::int n from numeros n join ordenes o on o.id = n.orden_id
       where o.ref = $1 and n.estado = 'vendido'`, [mamo.ref]);
    assert.equal(vendidosMamo.rows[0].n, 0);
  });

  it('un pago con referencia desconocida no habilita ninguna orden', async () => {
    const o = await crearOrden(pool, comprador());
    const r = await procesarPago(pool, mp, mp.simularPago({ ref: 'ORD-INEXISTE', amount: o.monto }));
    assert.equal(r.resultado, 'sin_orden');
    assert.equal((await estadoOrden(pool, o.ref)).estado, 'pendiente');
  });

  it('un pago sin referencia no habilita ninguna orden', async () => {
    const o = await crearOrden(pool, comprador());
    const r = await procesarPago(pool, mp, mp.simularPago({ ref: undefined, amount: o.monto }));
    assert.equal(r.resultado, 'sin_orden');
    assert.equal((await estadoOrden(pool, o.ref)).estado, 'pendiente');
  });

  it('un monto distinto al de la orden no asigna números', async () => {
    const o = await crearOrden(pool, comprador({ cantidad: 3 }));
    const r = await procesarPago(pool, mp, pagar(o, { amount: 20000 }));
    assert.equal(r.resultado, 'monto_distinto');
    assert.equal((await estadoOrden(pool, o.ref)).estado, 'pendiente');
  });

  it('pago pendiente o rechazado no asigna; si luego se aprueba, asigna una vez', async () => {
    const o = await crearOrden(pool, comprador());
    const pid = pagar(o, { status: 'pending' });
    assert.equal((await procesarPago(pool, mp, pid)).resultado, 'no_aprobado');
    assert.equal((await estadoOrden(pool, o.ref)).estado, 'pendiente');
    mp.cambiarEstado(pid, 'approved');
    assert.equal((await procesarPago(pool, mp, pid)).resultado, 'asignado');
    assert.equal((await estadoOrden(pool, o.ref)).estado, 'pagada');
  });
});

describe('pagos repetidos y simultáneos', () => {
  it('50 avisos simultáneos del mismo pago asignan una sola vez', async () => {
    const o = await crearOrden(pool, comprador({ cantidad: 4 }));
    const pid = pagar(o);
    const antes = await contar(pool, 'vendido');
    const rs = await Promise.all(Array.from({ length: 50 }, () => procesarPago(pool, mp, pid)));
    assert.equal(rs.filter((r) => r.resultado === 'asignado' && !r.repetido).length, 1);
    assert.equal(await contar(pool, 'vendido') - antes, 4);
    const filas = await pool.query('select count(*)::int n from pagos where mp_payment_id = $1', [pid]);
    assert.equal(filas.rows[0].n, 1);
    const notifs = await pool.query('select count(*)::int n from notificaciones where orden_id = (select id from ordenes where ref = $1)', [o.ref]);
    assert.equal(notifs.rows[0].n, 1, 'un solo comprobante');
  });

  it('dos pagos distintos para la misma orden: el segundo queda para reembolso', async () => {
    const o = await crearOrden(pool, comprador({ cantidad: 2 }));
    const p1 = pagar(o); const p2 = pagar(o);
    const antes = await contar(pool, 'vendido');
    const rs = await Promise.all([procesarPago(pool, mp, p1), procesarPago(pool, mp, p2)]);
    assert.deepEqual(rs.map((r) => r.resultado).sort(), ['asignado', 'requiere_reembolso']);
    assert.equal(await contar(pool, 'vendido') - antes, 2, 'solo 2 números, no 4');
    const c = await conciliacion(pool);
    assert.equal(c.problemas.reembolsos.length >= 1, true);
  });
});

describe('reservas y vencimiento', () => {
  it('si la reserva venció y el número lo tomó otro, el pago tardío va a reembolso', async () => {
    const a = await crearOrden(pool, comprador({ modo: 'elegir', cantidad: 1, numeros: [1500] }));
    await pool.query(`update numeros set reservado_hasta = now() - interval '1 minute' where numero = 1500`);
    await liberarVencidas(pool);
    const b = await crearOrden(pool, comprador({ nombre: 'Otro', modo: 'elegir', cantidad: 1, numeros: [1500] }));
    assert.equal((await procesarPago(pool, mp, pagar(b))).resultado, 'asignado');
    const tarde = await procesarPago(pool, mp, pagar(a));
    assert.equal(tarde.resultado, 'requiere_reembolso');
    assert.equal((await estadoOrden(pool, b.ref)).numeros[0], '1500');
  });

  it('si la reserva venció pero nadie tomó el número, el pago tardío igual se asigna', async () => {
    const a = await crearOrden(pool, comprador({ modo: 'elegir', cantidad: 1, numeros: [1499] }));
    await pool.query(`update numeros set reservado_hasta = now() - interval '1 minute' where numero = 1499`);
    await liberarVencidas(pool);
    assert.equal((await procesarPago(pool, mp, pagar(a))).resultado, 'asignado');
    assert.deepEqual((await estadoOrden(pool, a.ref)).numeros, ['1499']);
  });

  it('un pago al azar con reserva vencida consigue números nuevos sin repetir ninguno', async () => {
    const a = await crearOrden(pool, comprador({ cantidad: 5 }));
    await pool.query(
      `update numeros set reservado_hasta = now() - interval '1 minute'
       where orden_id = (select id from ordenes where ref = $1)`, [a.ref]);
    await liberarVencidas(pool);
    assert.equal((await procesarPago(pool, mp, pagar(a))).resultado, 'asignado');
    const nums = (await estadoOrden(pool, a.ref)).numeros;
    assert.equal(new Set(nums).size, 5);
  });
});

describe('vendedor (nombre completo y categoría)', () => {
  const rechaza = (extra, codigo) => assert.rejects(crearOrden(pool, comprador(extra)), (e) => e.codigo === codigo);

  it('exige nombre completo y categoría válida', async () => {
    await rechaza({ vendedorNombre: '' }, 'vendedor_nombre_invalido');
    await rechaza({ vendedorNombre: undefined }, 'vendedor_nombre_invalido');
    await rechaza({ vendedorNombre: 'Mateo' }, 'vendedor_nombre_invalido');          // solo nombre
    await rechaza({ vendedorNombre: 'M G' }, 'vendedor_nombre_invalido');            // iniciales
    await rechaza({ vendedorNombre: 'Mateo 123' }, 'vendedor_nombre_invalido');      // números
    await rechaza({ vendedorNombre: 'Mateo <b>Gómez' }, 'vendedor_nombre_invalido'); // caracteres raros
    await rechaza({ vendedorNombre: 'a '.repeat(50) }, 'vendedor_nombre_invalido');  // demasiado largo
    await rechaza({ vendedorCategoria: '' }, 'vendedor_categoria_invalida');
    await rechaza({ vendedorCategoria: 'M99' }, 'vendedor_categoria_invalida');
    assert.equal((await pool.query('select count(*)::int n from ordenes where vendedor_nombre is null')).rows[0].n, 0);
  });

  it('asocia la venta al jugador y a su categoría, y arma el comprobante con su nombre', async () => {
    const o = await crearOrden(pool, comprador({ cantidad: 3, vendedorNombre: '  Valentina   Ruiz ', vendedorCategoria: 'M16' }));
    await procesarPago(pool, mp, pagar(o));
    const p = await panel(pool);
    const v = p.porJugador.find((x) => x.vendedor === 'Valentina Ruiz');
    assert.equal(v.numeros, 3);
    assert.equal(v.categoria, 'M16');
    const notif = await pool.query(
      `select payload from notificaciones where orden_id = (select id from ordenes where ref = $1)`, [o.ref]);
    assert.match(notif.rows[0].payload.vendedor, /Valentina Ruiz \(M16\)/);
  });

  it('agrupa al mismo jugador aunque lo escriban con otras tildes o mayúsculas', async () => {
    for (const nombre of ['Tomás Aguirre', 'tomas aguirre', 'TOMÁS  AGUIRRE']) {
      const o = await crearOrden(pool, comprador({ vendedorNombre: nombre, vendedorCategoria: 'M14' }));
      await procesarPago(pool, mp, pagar(o));
    }
    const filas = (await panel(pool)).porJugador.filter((x) => /^tom/i.test(x.vendedor));
    assert.equal(filas.length, 1, JSON.stringify(filas));
    assert.equal(filas[0].numeros, 3);
    assert.equal(filas[0].vendedor, 'Tomás Aguirre', 'se muestra la versión con tilde y mayúsculas prolijas');
  });

  it('guarda el nombre con mayúsculas prolijas', async () => {
    const o = await crearOrden(pool, comprador({ vendedorNombre: 'juan  CARLOS de la Cruz', vendedorCategoria: 'M8' }));
    const r = await pool.query('select vendedor_nombre from ordenes where ref = $1', [o.ref]);
    assert.equal(r.rows[0].vendedor_nombre, 'Juan Carlos de la Cruz');
  });

  it('un mismo nombre en categorías distintas cuenta por separado', async () => {
    for (const cat of ['M10', 'M11']) {
      const o = await crearOrden(pool, comprador({ vendedorNombre: 'Santiago Pérez', vendedorCategoria: cat }));
      await procesarPago(pool, mp, pagar(o));
    }
    const filas = (await panel(pool)).porJugador.filter((x) => x.vendedor === 'Santiago Pérez');
    assert.deepEqual(filas.map((x) => x.categoria).sort(), ['M10', 'M11']);
  });

  it('el panel suma por categoría', async () => {
    const porCat = Object.fromEntries((await panel(pool)).porCategoria.map((x) => [x.categoria, x.numeros]));
    assert.equal(porCat.M16, 3);
    assert.equal(porCat.M14, 3);
  });
});

describe('aviso a compradores (panel)', () => {
  it('lista solo compras pagadas, con sus números, y cuenta las pendientes de aviso', async () => {
    const pagada = await crearOrden(pool, comprador({ nombre: 'Aviso Uno', whatsapp: '1144440001', cantidad: 3 }));
    const sinPagar = await crearOrden(pool, comprador({ nombre: 'Aviso Sin Pagar', whatsapp: '1144440002' }));
    await procesarPago(pool, mp, pagar(pagada));
    const p = await panel(pool);
    const c = p.compradores.find((x) => x.ref === pagada.ref);
    assert.equal(c.comprador, 'Aviso Uno');
    assert.equal(c.whatsapp, '1144440001');
    assert.equal(c.numeros.length, 3);
    assert.match(c.numeros[0], /^\d{4}$/);
    assert.equal(c.avisado_en, null);
    assert.equal(p.compradores.some((x) => x.ref === sinPagar.ref), false, 'una orden sin pagar no se muestra');
    assert.equal(p.sinAvisar, p.compradores.filter((x) => !x.avisado_en).length);
  });

  it('marcar como avisado descuenta de pendientes y se puede deshacer', async () => {
    const o = await crearOrden(pool, comprador({ nombre: 'Aviso Dos', cantidad: 1 }));
    await procesarPago(pool, mp, pagar(o));
    const antes = (await panel(pool)).sinAvisar;
    const r = await marcarAvisado(pool, o.ref, true);
    assert.ok(r.avisado_en);
    const mid = await panel(pool);
    assert.equal(mid.sinAvisar, antes - 1);
    assert.ok(mid.compradores.find((x) => x.ref === o.ref).avisado_en);
    await marcarAvisado(pool, o.ref, false);
    assert.equal((await panel(pool)).sinAvisar, antes);
  });

  it('no se puede marcar una orden inexistente ni una sin pagar', async () => {
    await assert.rejects(marcarAvisado(pool, 'ORD-NOEXISTE'), (e) => e.codigo === 'orden_inexistente');
    const o = await crearOrden(pool, comprador({ nombre: 'Aviso Tres' }));
    await assert.rejects(marcarAvisado(pool, o.ref), (e) => e.codigo === 'orden_inexistente');
  });

  it('cuando el comprador toca su botón queda registrado, pero no cuenta como avisado', async () => {
    const o = await crearOrden(pool, comprador({ nombre: 'Aviso Cuatro' }));
    await procesarPago(pool, mp, pagar(o));
    await marcarWspTocado(pool, o.ref);
    await marcarWspTocado(pool, o.ref);   // repetido: no falla ni cambia el aviso
    const c = (await panel(pool)).compradores.find((x) => x.ref === o.ref);
    assert.ok(c.wsp_tocado_en);
    assert.equal(c.avisado_en, null);
  });
});

describe('cancelar y eliminar compras (panel)', () => {
  it('cancelar libera los números, la saca de las ventas y la deja registrada', async () => {
    const o = await crearOrden(pool, comprador({ nombre: 'Cancelar Uno', cantidad: 3 }));
    await procesarPago(pool, mp, pagar(o));
    const nums = (await estadoOrden(pool, o.ref)).numeros;
    const antes = await panel(pool);
    const r = await cancelarCompra(pool, o.ref);
    assert.equal(r.estado, 'cancelada');
    assert.deepEqual(r.numeros, nums);
    assert.equal(r.devolver.estado_mp, 'approved', 'avisa que hay un pago para devolver');
    const despues = await panel(pool);
    assert.equal(despues.vendidos, antes.vendidos - 3);
    assert.equal(despues.recaudado, antes.recaudado - 3 * 20000);
    const c = despues.compradores.find((x) => x.ref === o.ref);
    assert.equal(c.estado, 'cancelada');
    assert.deepEqual(c.numeros, nums, 'guarda qué números tenía');
    assert.equal(despues.sinAvisar, antes.sinAvisar - 1);
    assert.equal((await estadoOrden(pool, o.ref)).estado, 'cancelada');
    assert.equal((await estadoOrden(pool, o.ref)).numeros, undefined);
    assert.equal((await conciliacion(pool)).coherente, true);
  });

  it('cancelar dos veces es seguro y no cambia nada', async () => {
    const o = await crearOrden(pool, comprador({ nombre: 'Cancelar Dos' }));
    await procesarPago(pool, mp, pagar(o));
    await cancelarCompra(pool, o.ref);
    const r = await cancelarCompra(pool, o.ref);
    assert.equal(r.repetido, true);
    await assert.rejects(cancelarCompra(pool, 'ORD-NOEXISTE'), (e) => e.codigo === 'orden_inexistente');
  });

  it('los números cancelados quedan libres y los puede comprar otra persona', async () => {
    const a = await crearOrden(pool, comprador({ nombre: 'Cancelar Tres', modo: 'elegir', cantidad: 1, numeros: [1600] }));
    await procesarPago(pool, mp, pagar(a));
    await cancelarCompra(pool, a.ref);
    const b = await crearOrden(pool, comprador({ nombre: 'Compra el 1600', modo: 'elegir', cantidad: 1, numeros: [1600] }));
    assert.equal((await procesarPago(pool, mp, pagar(b))).resultado, 'asignado');
    assert.deepEqual((await estadoOrden(pool, b.ref)).numeros, ['1600']);
  });

  it('un pago atrasado de una compra cancelada NO le vuelve a dar números: va a reembolso', async () => {
    const o = await crearOrden(pool, comprador({ nombre: 'Cancelar Cuatro', cantidad: 2 }));
    await cancelarCompra(pool, o.ref);                 // cancelada antes de que se acredite el pago
    const antes = await contar(pool, 'vendido');
    const r = await procesarPago(pool, mp, pagar(o));
    assert.equal(r.resultado, 'requiere_reembolso');
    assert.equal(await contar(pool, 'vendido'), antes, 'no se vendió ningún número');
    assert.equal((await estadoOrden(pool, o.ref)).estado, 'cancelada');
    const c = await conciliacion(pool);
    assert.equal(c.problemas.reembolsos.some((x) => x.external_reference === o.ref), true);
  });

  it('una compra cancelada que tenía pago aprobado figura como reintegro pendiente', async () => {
    const o = await crearOrden(pool, comprador({ nombre: 'Cancelar Cinco' }));
    await procesarPago(pool, mp, pagar(o));
    await cancelarCompra(pool, o.ref);
    const c = await conciliacion(pool);
    assert.equal(c.reintegrosPendientes.some((x) => x.ref === o.ref), true);
  });

  it('solo se puede eliminar una compra ya cancelada, y se borra por completo', async () => {
    const o = await crearOrden(pool, comprador({ nombre: 'Eliminar Uno', cantidad: 2 }));
    await procesarPago(pool, mp, pagar(o));
    await assert.rejects(eliminarCompra(pool, o.ref), (e) => e.codigo === 'primero_cancelar');
    assert.equal((await estadoOrden(pool, o.ref)).estado, 'pagada', 'no se tocó');
    await cancelarCompra(pool, o.ref);
    const r = await eliminarCompra(pool, o.ref);
    assert.equal(r.eliminada, true);
    assert.equal(await estadoOrden(pool, o.ref), null);
    const filas = await pool.query(
      `select (select count(*)::int from pagos where external_reference = $1) p,
              (select count(*)::int from notificaciones n join ordenes o on o.id = n.orden_id where o.ref = $1) n`, [o.ref]);
    assert.equal(filas.rows[0].n, 0);
    await assert.rejects(eliminarCompra(pool, o.ref), (e) => e.codigo === 'orden_inexistente');
  });

  it('aplicar el esquema de nuevo es seguro (se corre en cada arranque del servidor)', async () => {
    await aplicarEsquema(pool); await aplicarEsquema(pool);
    const r = await pool.query(`select count(*)::int n from pg_constraint where conrelid = 'ordenes'::regclass and contype = 'c' and pg_get_constraintdef(oid) like '%cancelada%'`);
    assert.equal(r.rows[0].n, 1, 'una sola regla de estados');
  });
});

describe('sorteo extra de premios de sponsors', () => {
  const pagarCompra = async (nombre, cantidad) => {
    const o = await crearOrden(pool, comprador({ nombre, cantidad }));
    await procesarPago(pool, mp, pagar(o));
    return o;
  };

  it(`una chance cada ${SORTEO_CADA} números, y solo cuentan las compras pagadas`, async () => {
    assert.equal(chancesDe(2), 0);
    assert.equal(chancesDe(3), 1);
    assert.equal(chancesDe(8), 2);
    assert.equal(chancesDe(9), 3);
    const chica = await pagarCompra('Extra Chica', 2);
    const grande = await pagarCompra('Extra Grande', 7);
    assert.equal((await estadoOrden(pool, chica.ref)).chances, 0);
    assert.equal((await estadoOrden(pool, grande.ref)).chances, 2);
    const sinPagar = await crearOrden(pool, comprador({ nombre: 'Extra Sin Pagar', cantidad: 6 }));
    assert.equal((await estadoOrden(pool, sinPagar.ref)).chances, undefined);
    const p = (await panel(pool)).sorteoExtra;
    assert.ok(p.chances >= 2 && p.participantes >= 1);
    assert.equal(p.cada, SORTEO_CADA);
  });

  it('sortea entre compras elegibles, una compra gana una sola vez y no gana una cancelada', async () => {
    const a = await pagarCompra('Sorteo A', 3);
    const b = await pagarCompra('Sorteo B', 3);
    const antes = (await panel(pool)).sorteoExtra.ganadores.length;
    await assert.rejects(sortearExtra(pool, { premio: '  ' }), (e) => e.codigo === 'premio_vacio');
    const ganados = new Set();
    for (let i = 0; i < 40; i++) {
      let r;
      try { r = await sortearExtra(pool, { premio: `Premio ${i}` }); } catch (e) { assert.equal(e.codigo, 'sin_participantes'); break; }
      assert.ok(!ganados.has(r.ref), 'una compra no gana dos veces');
      ganados.add(r.ref);
    }
    assert.ok(ganados.has(a.ref) && ganados.has(b.ref), 'con pocos participantes todos terminan ganando');
    const gan = (await panel(pool)).sorteoExtra.ganadores;
    assert.equal(gan.length, antes + ganados.size);
    const g = gan.find((x) => x.ref === a.ref);
    assert.ok(g.premio && g.whatsapp && !g.anulado_en);
    await cancelarCompra(pool, a.ref);
    assert.ok((await panel(pool)).sorteoExtra.ganadores.find((x) => x.ref === a.ref).anulado_en);
    const c = await pagarCompra('Sorteo C', 3);
    const r = await sortearExtra(pool, { premio: 'Premio tras cancelar' });
    assert.equal(r.ref, c.ref);
    assert.equal((await sortearExtra(pool, { premio: 'x' }).catch((e) => e.codigo)), 'sin_participantes');
  });

  it('la lista de premios de la web se lee de PREMIOS_SORTEO_EXTRA', () => {
    assert.deepEqual(leerPremios('La Genovesa: Vale de $50.000; Pizza Hot: 2 pizzas\n Sorteo sin sponsor ;;'), [
      { sponsor: 'La Genovesa', premio: 'Vale de $50.000' },
      { sponsor: 'Pizza Hot', premio: '2 pizzas' },
      { sponsor: '', premio: 'Sorteo sin sponsor' },
    ]);
    assert.deepEqual(leerPremios(undefined), []);
  });

  it('el azar se reparte según las chances', async () => {
    // Con 1 chance contra 6, la compra grande tiene que ganar claramente más seguido.
    let grande = 0;
    for (let i = 0; i < 60; i++) {
      const ch = await pagarCompra(`Peso Chica ${i}`, 3);
      const gr = await pagarCompra(`Peso Grande ${i}`, 18);
      const r = await sortearExtra(pool, { premio: `Peso ${i}` });
      if (r.ref === gr.ref) grande++;
      // dejar la base limpia de elegibles para la próxima vuelta
      for (let k = 0; k < 5; k++) { try { await sortearExtra(pool, { premio: 'resto' }); } catch { break; } }
      void ch;
    }
    assert.ok(grande > 35, `la compra con 6 chances ganó ${grande}/60`);
  });
});

describe('conciliación', () => {
  it('después de todo lo anterior, ventas, pagos y números cierran', async () => {
    const c = await conciliacion(pool);
    assert.equal(c.coherente, true, JSON.stringify(c.problemas));
    assert.equal(c.vendidos, c.esperados);
  });
});
