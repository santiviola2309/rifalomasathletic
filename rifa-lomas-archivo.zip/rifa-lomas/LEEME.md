# Rifa de fin de año · Lomas Athletic Club (archivo)

Versión final de la rifa del Lomas, guardada para usarla de nuevo.

## Qué tiene
- `web/rifa-lomas.html`: la web completa (home, compra, panel de organizadores, sponsors, sorteo extra).
- `backend/`: el servidor (Node 22 + Postgres 16), las pruebas (`npm test`) y el README con la explicación técnica.
- `material/rifa-qr-imprimir.pdf`: afiche con QR y tarjetas para imprimir.

## Cómo se vendía
- 1.700 números del 0001 al 1700 a $20.000, máximo 20 por compra, asignados al azar al acreditarse el pago en Mercado Pago.
- La venta se atribuye al jugador y su categoría (el comprador escribe nombre completo y categoría).
- Compras de 3 o más números: una chance cada 3 números en un sorteo extra de premios de sponsors (se sortea desde el panel).
- Panel de organizadores en `/#panel`: ventas, ranking por jugador y categoría, aviso a compradores por WhatsApp, cancelar y eliminar compras, sorteo extra.

## Para volver a usarla
1. Copiar `web/` y `backend/` a un repositorio nuevo (no mezclar con otro evento).
2. Crear una base Postgres nueva y cargar las variables de `backend/.env.example` en el servidor.
3. Revisar en `backend/src/orders.js` el precio y la cantidad de números, y en la web los textos, fechas y sponsors.
4. Los datos de compras de aquel evento NO están acá: quedaron en la base de datos de Render de aquel momento.

Ojo: la versión del bingo del Colegio Balmoral usa el mismo esqueleto pero cambia la base de datos (cartones 1 a 500). No usar la misma base para los dos eventos.
