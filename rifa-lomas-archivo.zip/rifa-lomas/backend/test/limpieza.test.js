import assert from 'node:assert/strict';
import { after, before, describe, it } from 'node:test';
import { crearOrden, estadoOrden, panel, procesarPago } from '../src/orders.js';
import { limpiarPruebas, listarOrdenes } from '../src/limpieza.js';
import { comprador, contar, nuevoEntorno } from './helpers.js';

let pool, mp;
before(async () => { ({ pool, mp } = await nuevoEntorno()); });
after(() => pool.end());

const crearPagada = async (extra) => {
  const o = await crearOrden(pool, comprador(extra));
  await procesarPago(pool, mp, mp.simularPago({ ref: o.ref, amount: o.monto }));
  return o;
};
const envejecer = (ref) => pool.query(`update ordenes set creada_en = now() - interval '2 hours' where ref = $1`, [ref]);

describe('limpieza de compras de prueba', () => {
  it('no hace nada sin indicar qué conservar, ni si la compra no existe', async () => {
    await assert.rejects(limpiarPruebas(pool, {}), /al menos una compra/);
    await assert.rejects(limpiarPruebas(pool, { conservar: ['ORD-NOEXISTE'], confirmar: true }), /No existe la compra/);
  });

  it('el simulacro informa pero no borra', async () => {
    const real = await crearPagada({ nombre: 'Martín Rodríguez', cantidad: 2 });
    const prueba = await crearPagada({ nombre: 'Prueba Uno', cantidad: 3 });
    await envejecer(real.ref); await envejecer(prueba.ref);
    const r = await limpiarPruebas(pool, { conservar: [real.ref] });
    assert.equal(r.confirmado, false);
    assert.deepEqual(r.aBorrar.map((o) => o.ref), [prueba.ref]);
    assert.equal((await listarOrdenes(pool)).length, 2);
    assert.equal(await contar(pool, 'vendido'), 5);
  });

  it('al confirmar conserva la compra real, libera los números de las demás y deja la base consistente', async () => {
    const real = (await listarOrdenes(pool)).find((o) => o.comprador === 'Martín Rodríguez');
    const numerosReales = real.numeros;
    const pendienteViejo = await crearOrden(pool, comprador({ nombre: 'Pendiente viejo' }));
    await envejecer(pendienteViejo.ref);
    const r = await limpiarPruebas(pool, { conservar: [real.ref], confirmar: true });
    assert.equal(r.confirmado, true);
    const quedan = await listarOrdenes(pool);
    assert.deepEqual(quedan.map((o) => o.ref), [real.ref]);
    assert.deepEqual(quedan[0].numeros, numerosReales);
    assert.equal(quedan[0].pagos.length, 1);
    assert.equal(await contar(pool, 'vendido'), 2);
    assert.equal(await contar(pool, 'reservado'), 0);
    assert.equal(await contar(pool, 'libre'), 1698);
    assert.equal((await pool.query('select count(*)::int n from notificaciones')).rows[0].n, 1);
    assert.equal((await estadoOrden(pool, real.ref)).estado, 'pagada');
    assert.equal((await panel(pool)).vendidos, 2);
  });

  it('no toca una compra pendiente reciente: puede ser alguien pagando en este momento', async () => {
    const real = (await listarOrdenes(pool))[0];
    const enCurso = await crearOrden(pool, comprador({ nombre: 'Pagando ahora' }));
    const r = await limpiarPruebas(pool, { conservar: [real.ref], confirmar: true });
    assert.deepEqual(r.protegidas.map((o) => o.ref), [enCurso.ref]);
    assert.equal((await estadoOrden(pool, enCurso.ref)).estado, 'pendiente');
  });
});
