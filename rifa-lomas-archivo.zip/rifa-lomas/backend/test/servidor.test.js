import assert from 'node:assert/strict';
import { createServer as createNetServer } from 'node:net';
import { after, before, describe, it } from 'node:test';
import { crearApp } from '../src/server.js';
import { crearMpSimulado, firmar, verificarFirma } from '../src/mp.js';
import { nuevoEntorno } from './helpers.js';

let pool, mp, server, base;
const SECRETO = 'secreto-de-prueba';
const VEND = { vendedorNombre: 'Mateo Gómez', vendedorCategoria: 'M12' };

before(async () => {
  ({ pool, mp } = await nuevoEntorno());
  // Puerto libre elegido de antemano: el checkout simulado necesita conocer su propia URL.
  const sonda = createNetServer();
  await new Promise((r) => sonda.listen(0, '127.0.0.1', r));
  const puerto = sonda.address().port;
  await new Promise((r) => sonda.close(r));
  base = `http://127.0.0.1:${puerto}`;
  mp = crearMpSimulado({ baseUrl: base });
  server = crearApp({ pool, mp, config: { baseUrl: base, webhookSecret: SECRETO, panelKey: 'clave-panel', maxOrdenesPorMinuto: 1000 } });
  await new Promise((r) => server.listen(puerto, '127.0.0.1', r));
});
after(async () => { server.close(); await pool.end(); });

const post = (ruta, cuerpo, headers = {}) => fetch(base + ruta, {
  method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(cuerpo),
});

describe('flujo completo (Mercado Pago simulado)', () => {
  it('crear pago → pagar en el checkout simulado → webhook firmado → números asignados', async () => {
    const r = await post('/api/crear-pago', {
      nombre: 'Ana', whatsapp: '1166660000', cantidad: 2, modo: 'azar',
      vendedorNombre: 'Valentina Ruiz', vendedorCategoria: 'M16',
    });
    assert.equal(r.status, 201);
    const { ref, init_point, monto } = await r.json();
    assert.equal(monto, 40000);
    assert.match(init_point, /\/mock-mp\//);

    const antes = await (await fetch(`${base}/api/orden/${ref}`)).json();
    assert.equal(antes.estado, 'pendiente');

    const pago = await fetch(init_point, {
      method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: 'status=approved', redirect: 'manual',
    });
    assert.equal(pago.status, 303);

    const despues = await (await fetch(`${base}/api/orden/${ref}`)).json();
    assert.equal(despues.estado, 'pagada');
    assert.equal(despues.numeros.length, 2);

    const p = await (await fetch(`${base}/api/panel`, { headers: { 'x-panel-key': 'clave-panel' } })).json();
    assert.equal(p.vendidos, 2);
    assert.equal(p.porJugador[0].vendedor, 'Valentina Ruiz');
  });

  it('pago rechazado no asigna números', async () => {
    const { ref, init_point } = await (await post('/api/crear-pago', {
      ...VEND, nombre: 'Beto', whatsapp: '1155550000', cantidad: 1, modo: 'azar',
    })).json();
    await fetch(init_point, {
      method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: 'status=rejected', redirect: 'manual',
    });
    assert.equal((await (await fetch(`${base}/api/orden/${ref}`)).json()).estado, 'pendiente');
  });

  it('un webhook sin firma válida se rechaza y no procesa nada', async () => {
    const { ref, monto } = await (await post('/api/crear-pago', { ...VEND, nombre: 'C', whatsapp: '1155550000', cantidad: 1, modo: 'azar' })).json();
    const pid = mp.simularPago({ ref, amount: monto });
    const sinFirma = await post(`/api/mp-webhook?type=payment&data.id=${pid}`, {});
    assert.equal(sinFirma.status, 401);
    const mala = await post(`/api/mp-webhook?type=payment&data.id=${pid}`, {}, { 'x-signature': 'ts=1,v1=00', 'x-request-id': 'x' });
    assert.equal(mala.status, 401);
    assert.equal((await (await fetch(`${base}/api/orden/${ref}`)).json()).estado, 'pendiente');
    const buena = await post(`/api/mp-webhook?type=payment&data.id=${pid}`, {}, {
      'x-request-id': 'r1', 'x-signature': firmar({ secreto: SECRETO, requestId: 'r1', dataId: pid }),
    });
    assert.equal(buena.status, 200);
    assert.equal((await (await fetch(`${base}/api/orden/${ref}`)).json()).estado, 'pagada');
  });

  it('el panel exige clave', async () => {
    assert.equal((await fetch(`${base}/api/panel`)).status, 401);
    assert.equal((await fetch(`${base}/api/panel`, { headers: { 'x-panel-key': 'mala' } })).status, 401);
  });

  it('valida entradas: código inexistente, cantidad inválida, número ya reservado', async () => {
    const sinNombre = await post('/api/crear-pago', { nombre: 'X', whatsapp: '1155550000', cantidad: 1, modo: 'azar', vendedorCategoria: 'M12' });
    assert.equal(sinNombre.status, 400);
    assert.equal((await sinNombre.json()).error, 'vendedor_nombre_invalido');
    const soloNombre = await post('/api/crear-pago', { nombre: 'X', whatsapp: '1155550000', cantidad: 1, modo: 'azar', vendedorNombre: 'Mateo', vendedorCategoria: 'M12' });
    assert.equal((await soloNombre.json()).error, 'vendedor_nombre_invalido');
    const sinCat = await post('/api/crear-pago', { nombre: 'X', whatsapp: '1155550000', cantidad: 1, modo: 'azar', vendedorNombre: 'Mateo Gómez' });
    assert.equal((await sinCat.json()).error, 'vendedor_categoria_invalida');
    const c = await post('/api/crear-pago', { ...VEND, nombre: 'X', whatsapp: '1155550000', cantidad: 99, modo: 'azar' });
    assert.equal((await c.json()).error, 'cantidad_invalida');
    // Solo al azar: aunque pidan elegir el 321, el servidor asigna al azar y lo ignora.
    for (const quien of ['X', 'Y']) {
      const r = await post('/api/crear-pago', { ...VEND, nombre: quien, whatsapp: '1155550000', cantidad: 1, modo: 'elegir', numeros: [321] });
      assert.equal(r.status, 201);
    }
    const reservados = await pool.query(`select count(*)::int n from numeros where numero = 321 and estado <> 'libre'`);
    assert.equal(reservados.rows[0].n, 0, 'el 321 no queda reservado por pedirlo');
    const ordenes = await pool.query(`select count(*)::int n from ordenes where modo = 'elegir'`);
    assert.equal(ordenes.rows[0].n, 0, 'no se crean órdenes de números elegidos');
  });
});

describe('validación del WhatsApp del comprador', () => {
  it('rechaza números que no pueden ser un celular argentino', async () => {
    for (const malo of ['123', '1', '0000000000', '1111111111', '11 5555', 'abc', '555-1234']) {
      const r = await post('/api/crear-pago', { ...VEND, nombre: 'Z', whatsapp: malo, cantidad: 1, modo: 'azar' });
      assert.equal(r.status, 400, malo);
      assert.equal((await r.json()).error, 'whatsapp_invalido', malo);
    }
  });

  it('acepta los formatos habituales de celular', async () => {
    for (const bueno of ['11 5555-1234', '1155551234', '011 15 5555-1234', '+54 9 11 5555-1234', '(11) 5555 1234', '351 612-3456']) {
      const r = await post('/api/crear-pago', { ...VEND, nombre: 'Z', whatsapp: bueno, cantidad: 1, modo: 'azar' });
      assert.equal(r.status, 201, bueno);
    }
  });
});

describe('avisos del panel', () => {
  it('marcar avisado exige la clave del panel y actualiza la lista', async () => {
    const { ref, init_point } = await (await post('/api/crear-pago', { ...VEND, nombre: 'Av', whatsapp: '1155550000', cantidad: 1, modo: 'azar' })).json();
    await fetch(init_point, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'status=approved', redirect: 'manual' });
    const sinClave = await post('/api/panel/avisado', { ref });
    assert.equal(sinClave.status, 401);
    const mala = await post('/api/panel/avisado', { ref }, { 'x-panel-key': 'mala' });
    assert.equal(mala.status, 401);
    const ok = await post('/api/panel/avisado', { ref }, { 'x-panel-key': 'clave-panel' });
    assert.equal(ok.status, 200);
    const p = await (await fetch(`${base}/api/panel`, { headers: { 'x-panel-key': 'clave-panel' } })).json();
    assert.ok(p.compradores.find((c) => c.ref === ref).avisado_en);
    const inexistente = await post('/api/panel/avisado', { ref: 'ORD-NOPE' }, { 'x-panel-key': 'clave-panel' });
    assert.equal(inexistente.status, 400);
  });

  it('el comprador puede dejar constancia de que tocó su botón sin necesitar clave', async () => {
    const { ref, init_point } = await (await post('/api/crear-pago', { ...VEND, nombre: 'Av2', whatsapp: '1155550000', cantidad: 1, modo: 'azar' })).json();
    await fetch(init_point, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'status=approved', redirect: 'manual' });
    assert.equal((await post(`/api/orden/${ref}/wsp`, {})).status, 200);
    const p = await (await fetch(`${base}/api/panel`, { headers: { 'x-panel-key': 'clave-panel' } })).json();
    const c = p.compradores.find((x) => x.ref === ref);
    assert.ok(c.wsp_tocado_en);
    assert.equal(c.avisado_en, null);
  });
});

describe('cancelar y eliminar desde el panel', () => {
  it('exigen la clave del panel y funcionan en orden: primero cancelar, después eliminar', async () => {
    const { ref, init_point } = await (await post('/api/crear-pago', { ...VEND, nombre: 'Can', whatsapp: '1155550000', cantidad: 2, modo: 'azar' })).json();
    await fetch(init_point, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'status=approved', redirect: 'manual' });
    const K = { 'x-panel-key': 'clave-panel' };
    for (const ruta of ['/api/panel/cancelar', '/api/panel/eliminar']) {
      assert.equal((await post(ruta, { ref })).status, 401);
      assert.equal((await post(ruta, { ref }, { 'x-panel-key': 'mala' })).status, 401);
    }
    const noAun = await post('/api/panel/eliminar', { ref }, K);
    assert.equal(noAun.status, 400);
    assert.equal((await noAun.json()).error, 'primero_cancelar');
    const c = await post('/api/panel/cancelar', { ref }, K);
    assert.equal(c.status, 200);
    const cj = await c.json();
    assert.equal(cj.estado, 'cancelada'); assert.equal(cj.numeros.length, 2); assert.ok(cj.devolver);
    const p = await (await fetch(`${base}/api/panel`, { headers: K })).json();
    assert.equal(p.compradores.find((x) => x.ref === ref).estado, 'cancelada');
    assert.equal((await post('/api/panel/eliminar', { ref }, K)).status, 200);
    assert.equal((await fetch(`${base}/api/orden/${ref}`)).status, 404);
  });
});

describe('sorteo extra por la web', () => {
  const pagarWeb = async (nombre, cantidad) => {
    const { ref, init_point } = await (await post('/api/crear-pago', { ...VEND, nombre, whatsapp: '1155550000', cantidad, modo: 'azar' })).json();
    await fetch(init_point, { method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' }, body: 'status=approved', redirect: 'manual' });
    return ref;
  };

  it('el comprador ve sus chances y el panel sortea con clave', async () => {
    const ref = await pagarWeb('Ex', 6);
    assert.equal((await (await fetch(`${base}/api/orden/${ref}`)).json()).chances, 2);
    const K = { 'x-panel-key': 'clave-panel' };
    assert.equal((await post('/api/panel/sorteo-extra', { premio: 'Cena para dos' })).status, 401);
    assert.equal((await post('/api/panel/sorteo-extra', { premio: '' }, K)).status, 400);
    const ok = await post('/api/panel/sorteo-extra', { premio: 'Cena para dos' }, K);
    assert.equal(ok.status, 200);
    const g = await ok.json();
    assert.equal(g.premio, 'Cena para dos');
    assert.ok(g.ref && g.whatsapp);
    const p = await (await fetch(`${base}/api/panel`, { headers: K })).json();
    assert.ok(p.sorteoExtra.ganadores.some((x) => x.id === g.id));
  });

  it('una compra de 2 números no tiene chances', async () => {
    const ref = await pagarWeb('Sc', 2);
    assert.equal((await (await fetch(`${base}/api/orden/${ref}`)).json()).chances, 0);
  });
});

describe('web', () => {
  it('sirve la web en modo servidor', async () => {
    const r = await fetch(`${base}/`);
    assert.equal(r.status, 200);
    const html = await r.text();
    assert.match(html, /window\.RIFA_API = ""/);
    assert.match(html, /Rifa de fin de año Lomas/);
  });

  it('ya no expone ninguna consulta de vendedores por código', async () => {
    assert.equal((await fetch(`${base}/api/vendedor/TIGRE47`)).status, 404);
  });

  it('el rechazo del checkout vuelve a la web marcado como rechazado', async () => {
    const { init_point } = await (await post('/api/crear-pago', { ...VEND, nombre: 'R', whatsapp: '1155550000', cantidad: 1, modo: 'azar' })).json();
    const r = await fetch(init_point, {
      method: 'POST', headers: { 'content-type': 'application/x-www-form-urlencoded' },
      body: 'status=rejected', redirect: 'manual',
    });
    assert.match(r.headers.get('location'), /^\/\?orden=ORD-[A-Z0-9]+&pago=rechazado$/);
  });
});

describe('firma del webhook', () => {
  it('acepta la firma correcta y rechaza una alterada', () => {
    const firma = firmar({ secreto: 's', requestId: 'r', dataId: '123' });
    assert.equal(verificarFirma({ secreto: 's', firma, requestId: 'r', dataId: '123' }), true);
    assert.equal(verificarFirma({ secreto: 's', firma, requestId: 'r', dataId: '124' }), false);
    assert.equal(verificarFirma({ secreto: 'otro', firma, requestId: 'r', dataId: '123' }), false);
    assert.equal(verificarFirma({ secreto: 's', firma: undefined, requestId: 'r', dataId: '123' }), false);
  });
});
